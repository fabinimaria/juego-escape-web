# Juego de Escape: La Caja Negra

Sitio estático en HTML/CSS/JS listo para publicar en GitHub Pages.

## Ejecutar local

Abrir `index.html` en el navegador.
